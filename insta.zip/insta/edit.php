<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body class="" style="background-color:#D2E0FB;">
    <div class="container">
    <h2 align="center">є∂ιт ρσѕтιиgαи</h2>
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">
        <div class="mb-3">
    <label for="" class="form-label">Foto</label>
    <input type="file" class="form-control" name="foto" id="" value="<?= $post['foto'] ?>"><br>
    <img src="data/<?= $post['foto'] ?>" width="100" alt="">
     </div>

    <div class="mb-3">
    <label for="" class="form-label">Caption</label>
    <input type="" class="form-control" name="caption" id="" autocomplete="off" value="<?= $post['caption'] ?>">
    </div>

    <div class="mb-3">
    <label for="" class="form-label">Lokasi</label>
    <input type="" class="form-control"  name="lokasi" id="" autocomplete="off" value="<?= $post['lokasi'] ?>">
    </div>

    <button type="submit" class="btn btn-primary" value="Update" name="Update">uр𝖽⍺tᥱ</button>

    </form>
    </div>
</body>
</html>

<?php } ?>