<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql="SELECT*FROM post ORDER BY no DESC";
$query=mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="data/nct.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>ᥒᥴ𝗍</title>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
      body{
        background-image: url(data/colour.jpg);
        background-size: cover;
        background-repeat:no-repeat;


      }
    .card-body img {
        transition: transform 0.3s;
    }

    .card-body img:hover {
        transform: scale(1.1);
    }
</style>
</head>
<body>
<nav class="sticky-top navbar navbar-light bg-light justify-content-between">
  <a class="navbar-brand" href="#">
  <img src = "/insta/data/nct.png" width="50" height = "40">🅝🅒🅣🅓🅐🅘🅛🅨</i>
    </a>
  <form class="form-inline">

    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-primary mr-4"><i class="bi bi-plus-square h5"></i></a><br>
    <a href="logout.php" class="btn btn-danger"><i class="bi bi-box-arrow-right h5"></i></a>
  </form>
</nav>
<br><br>
<center>
    <div class="container">
    <?php while($post = mysqli_fetch_assoc($query)) { ?>

      <div class="container d-flex justify-content-center">

<div class="card mt-5" >
  <div class="card-body">
    <img src="data/<?= $post['foto'] ?>" alt="" width="350">
       
        <h5 class="card-title"><?= $post['caption'] ?></h5>
        <p class="card-text"><?= $post['lokasi'] ?></p>
        <button class="btn btn-warning " data-bs-toggle="modal" data-bs-target="#staticBackdrop<?=$post['no']?>"><i class = "bi bi-pencil-square"></i></button>
        <a href="hapus.php?no=<?= $post['no']?>" class="btn btn-danger"><i class="bi bi-trash-fill"></i></a>
        
    </div>
</div>
</div>
    </br>
    <!-- modal edit -->
    <div class="modal fade" id="staticBackdrop<?=$post['no']?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style="background-color: #F1B4BB;">
        <h2 class="modal-title fs-5 text-white" id="staticBackdropLabel" >ᥱძі𝗍 ოᥱოᑲᥱr</h2>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>">

        <div class="container" align="left">
        <label for="">ріcturᥱ𝘴</label>
        

        <div align="left">
        <img src="data/<?= $post['foto'] ?>" width="100" alt=""><br><br>
        <input type="file" name="foto" class="form-control" value="<?= $post['foto'] ?>" ><br>
        </div>

       
        <label for="">ᥴᥲ⍴𝗍і᥆ᥒ</label>
        <input type="text" name="caption" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>
        

       
        <label for="">ᥣ𝘰k⍺𝘴і</label>
        <input type="text" name="lokasi" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        
        <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">bɑtɑᥣ</button>
        <input type="submit" value="ᥙ⍴ძᥲ𝗍ᥱ" name="ᥙ⍴ძᥲ𝗍ᥱ" class="btn btn-primary">
</div>
    </form>
</div>
      <div class="modal-footer">
        
      </div>
    </div>
  </div>
</div>
    </div>
    </div>
    </div>
    </div>
    <?php } ?>
    </div><br><br>
    <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel"></h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        
        <label for="" class="form-label">foto</label><br>
        <input class="form-control" type="file" name="foto" id="" required><br><br>

        <label for="" class="form-label">Caption</label><br>
        <input class="form-control" type="text" name="caption" id="" autocomplete="off"><br>

        <label for="" class="form-label">Lokasi</label><br>
        <input class="form-control" type="text" name="lokasi" id="" autocomplete="off"><br><br>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <input type="submit" class="btn btn-primary" value="Tambah" name="Posting"></button>
        </div>
    </form>
      </div>
    </div>
  </div>
</div>
    </div>
    </center>
</body>
</html>